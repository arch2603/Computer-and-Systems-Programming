
#ifndef SERVER_FUNCTIONS_H_INCLUDED
#define SERVER_FUNCTIONS_H_INCLUDED








Client_t* Authenticate(int sockfd, Client_t *head);
void sendClientData(int sockfd, Client_t *client);

#endif
